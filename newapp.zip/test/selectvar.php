 <?php
// header("Access-Control-Allow-Origin: *");

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "employee";

// // Create connection
// $conn = new mysqli($servername, $username, $password, $dbname);

// if(isset($_REQUEST['id']))
// {
//     $id = $_REQUEST['id'];
//     $sql = "DELETE FROM `emp_master` WHERE `empid` = '$id'";
//     $ex = $conn->query($sql);    
// }

// return http_response_code('204');

require 'database.php';
// echo json_encode("hii",true);
// return false;
// return http_response_code(400);
// Extract, validate and sanitize the id.
$id = ($_GET['id']);

//echo $id;
if(!$id)
{
  return http_response_code(400);
}
// Delete.
// echo json_encode($_GET['id'],true);
// return false;
$sql = "select * FROM `emp_master` WHERE `empid`=$id LIMIT 1";
$SqlEx = $conn->query($sql);

if($SqlEx->num_rows > 0)
{
  $FetchData = $SqlEx->fetch_object();
  // http_response_code(204);
}
else
{
  $FetchData = 'else';
  // http_response_code(422);
}

echo json_encode($FetchData,true);
return false;
?> 