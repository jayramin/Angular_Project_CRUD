<?php  
header("Access-Control-Allow-Origin: *");

$data=[];
$mysqli = new mysqli('127.0.0.1', 'root', '', 'employee');

if ($mysqli->connect_errno) {    
    echo json_encode($data);
}
else
{
    $sql = "SELECT empid, empname, empmobile,empcity FROM emp_master";
    if (!$result = $mysqli->query($sql)) {
        echo json_encode($data);
    }
    else
    {
        if ($result->num_rows === 0) {    
            echo json_encode($data);
        }
        else
        {                                    
            while ($actor = $result->fetch_assoc()) 
            {                
                $data[]=$actor;
            }        
            $result->free();
            $mysqli->close();
            echo json_encode($data);
        }    
    }
}
?>