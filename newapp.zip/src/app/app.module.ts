import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChildRouteRoutingModule} from './childroute/childroute-routing.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { NavbarComponent } from './navbar/navbar.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { ChildrouteComponent } from './childroute/childroute.component';
import { Page1Component } from './page1/page1.component';
import { Page2Component } from './page2/page2.component';
import {ProductService} from './product.service';
import {HttpClientModule} from '@angular/common/http';
import { AddempComponent } from './addemp/addemp.component';
import { FileUploadComponent } from './file-upload/file-upload.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomepageComponent,
    AboutusComponent,
    ContactusComponent,
    ChildrouteComponent,
    Page1Component,
    Page2Component,
    AddempComponent,
    FileUploadComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChildRouteRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
