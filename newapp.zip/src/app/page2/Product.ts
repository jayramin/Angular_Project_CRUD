export class product {
	
	public ProductName:string;
	public ProductPrice:number;
	public ProductQty:number;

	constructor(productName:string, productPrice:number, productQty:number) {		

		this.ProductName=productName;
		this.ProductPrice=productPrice;
		this.ProductQty=productQty;
	}
}