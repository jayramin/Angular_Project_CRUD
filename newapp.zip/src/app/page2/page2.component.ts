import { Component, OnInit } from '@angular/core';
import { product } from './Product';


@Component({
  selector: 'app-page2',
  templateUrl: './page2.component.html',
  styleUrls: ['./page2.component.css']
})
export class Page2Component implements OnInit {

  model = new product("",null,null);
  productList:Array<product> = new Array<product>();

  addProduct ()
  {
    this.productList.push(new product(this.model.ProductName,this.model.ProductPrice,this.model.ProductQty));
    this.clearcontrol();
  }
  private clearcontrol() {
    this.model = new product("", null, null);
  }

  editProduct (index:number)
  {
    this.clearcontrol();
    this.model = this.productList[index];
  }

  deleteProduct(index:number)
  {
    if (index > -1)
    {
      this.productList.splice(index);
    }
  }
  constructor() { }

  ngOnInit() {
  }

}
