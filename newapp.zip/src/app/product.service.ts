import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {Ipost} from './post';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  //private _url:string = "https://jsonplaceholder.typicode.com/posts";
  private _url:string = "http://localhost/test/index.php";

  constructor(private http:HttpClient) {
    
  
   }

   getperson():Observable<Ipost[]>
   {
    // console.log('ok');
     return this.http.get<Ipost[]>(this._url);
   } 
   
    DeleteData(empid:number)
    {
       return this.http.delete("http://localhost/test/delete.php?id="+empid, {responseType: 'text'});
    }

    EditData(empForm)
    {
       return this.http.post("http://localhost/test/update.php", empForm);
    }

    addemp(empForm)
    {
        
        //console.log(this.model.empname);
       return this.http.post("http://localhost/test/insert.php",empForm);  
  
  
    }

    selectvar(empid:number)
    {
      // console.log(empid);
       return this.http.get("http://localhost/test/selectvar.php?id="+empid, {responseType: 'text'});
    }
    getemp()
    {
      //return this.http.get("",emp);
    }

  /*getproduct (){return[
    {"productname":"Product 1", "price":20000,"qty":100},
    {"productname":"Product 2", "price":40000,"qty":200},
    {"productname":"Product 3", "price":60000,"qty":300}]
  };*/


}
