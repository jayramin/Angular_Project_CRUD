import { Component, OnInit } from '@angular/core';

import {HttpClient} from '@angular/common/http';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addemp',
  templateUrl: './addemp.component.html',
  styleUrls: ['./addemp.component.css']
})
export class AddempComponent implements OnInit {
  //model = new emp("",null,null);
  emp = [];
  editemp:any =[];
  model = { empname : null,empmobile :null,empcity:null };
  constructor(private _emp:ProductService,private router:Router) { }

  ngOnInit() 
  {
    this._emp.getperson().subscribe((data) => {this.emp = data;} );
  }

  addemp(empForm)
  {
      
      //console.log(this.model.empname);
      this._emp.addemp(empForm.value).subscribe((response) => {this.ngOnInit();  });
      this.clearcontrol();
      //this._emp.addemp(empForm.value).subscribe((response) => {console.log("Inserted",response);  });
      //this.router.navigate(['childroute/page1']);
        
  }

  clearcontrol()
  {
    this.model.empname = "";
    this.model.empmobile = "";
    this.model.empcity = "";
  }

  EditData (updateempid:number)
  {
    console.log("Edit call");
    console.log(updateempid);
    
    var test = this._emp.selectvar(updateempid).subscribe( (data) =>{  
      this.ngOnInit();
       this.model = JSON.parse(data);
      console.log(this.editemp.empname);
      
    });
    
    //this.model = this.emp.find(e=> e.empid1 = updateempid);
    

  }

  DeleteData(empid:number)
  {
    this._emp.DeleteData(empid).subscribe( (data) =>{  this.ngOnInit(); });
  }

}
