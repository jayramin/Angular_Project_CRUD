import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChildrouteComponent } from '../childroute/childroute.component';
import { Page1Component } from '../page1/page1.component'
import { Page2Component } from '../page2/page2.component';
import { AddempComponent } from '../addemp/addemp.component';

const routes: Routes = [

{path:'childroute',component:ChildrouteComponent,children:[
  {path:'',component:Page1Component},
    {path:'page1',component:Page1Component},
    {path:'page2',component:Page2Component},
    {path:'addemp',component:AddempComponent}]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class ChildRouteRoutingModule { }
