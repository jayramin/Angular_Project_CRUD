import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-childroute',
  templateUrl: './childroute.component.html',
  styleUrls: ['./childroute.component.css']
})
export class ChildrouteComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {

    
  }

}
