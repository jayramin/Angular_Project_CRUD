import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component implements OnInit {
  
  // access in html from productlist
 /* productlist:any[] = [
    {"productname":"Product 1", "price":200,"qty":100},
    {"productname":"Product 2", "price":400,"qty":200},
    {"productname":"Product 3", "price":600,"qty":300}
  ];
  pro = [];*/

  per = [];
  constructor(private _per:ProductService, private router:Router) { 
   
   
  }

  ngOnInit() {

   // alert('test');
    //this.pro = this._product.getproduct(); // From Array

    // From Database
    
    this._per.getperson().subscribe((data) => {   this.per = data;
      // if(data) {
      //     this.per = data;
      // } else {
      //   this.per = [];          
      // }
    }      
    );

    
  }

  DeleteData(empid:number)
  {
    this._per.DeleteData(empid).subscribe( (data) =>{  this.ngOnInit(); });
    
    
  }
  

}
