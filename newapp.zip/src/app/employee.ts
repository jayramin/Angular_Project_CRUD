
export interface Iemp{
	
	 empname:string;
	 empmobile:number;
	 empcity:number;


}