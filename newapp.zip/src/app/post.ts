export interface Ipost{
    "id":number,
    "empname":string,
    "empmobile":number,
    "empcity":string
}