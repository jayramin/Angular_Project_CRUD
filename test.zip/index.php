<?php  
header("Access-Control-Allow-Origin: *");

$data=[];
$mysqli = new mysqli("localhost","id9549810_typeandearn3","123456","id9549810_typeandearn3");

if ($mysqli->connect_errno) {    
    echo json_encode($data);
}
else
{
    $sql = "SELECT empid, empname, empmobile,empcity FROM emp_master";
    if (!$result = $mysqli->query($sql)) {
        echo json_encode($data);
    }
    else
    {
        if ($result->num_rows === 0) {    
            echo json_encode($data);
        }
        else
        {                                    
            while ($actor = $result->fetch_assoc()) 
            {                
                $data[]=$actor;
            }        
            $result->free();
            $mysqli->close();
            echo json_encode($data);
        }    
    }
}
?>