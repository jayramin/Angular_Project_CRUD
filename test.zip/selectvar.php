<?php

header("Access-Control-Allow-Origin: *");

$data=[];
$mysqli = new mysqli("localhost","id9549810_typeandearn3","123456","id9549810_typeandearn3");

if ($mysqli->connect_errno) {    
    echo json_encode($data);
}
else
{
    $id = ($_GET['id']);
    $sql = "SELECT * FROM emp_master  WHERE `empid`=$id LIMIT 1";
    if (!$result = $mysqli->query($sql)) {
        $data = array("in not result data");
        echo json_encode($data);
    }
    else
    {
        
        if ($result->num_rows === 0) {    
            $data = array("in num_rows if data");
            echo json_encode($data);
        }
        else
        {                                    
            while ($actor = $result->fetch_assoc()) 
            {                
                $data[]=$actor;
            }        
            $result->free();
            $mysqli->close();
            echo json_encode($data);
        }    
    }
}




?> 