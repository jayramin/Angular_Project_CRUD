<?php

header("Access-Control-Allow-Origin: *");

$data=[];
$mysqli = new mysqli("localhost","id9549810_typeandearn3","123456","id9549810_typeandearn3");

if ($mysqli->connect_errno) {    
    echo json_encode($data);
}
else
{
    
    
    $postdata = file_get_contents("php://input");
    // echo json_encode($postdata); 
    // exit;
    $sql = "INSERT INTO `emp_master`(`empname`,`empmobile`,`empcity`) VALUES ('$request->empname','$request->empmobile','$request->empcity')";
    
    if (!$result = $mysqli->query($sql)) {
        $data = array("in not result data");
        echo json_encode($data);
    }
    else
    {
        $data = array("Msg"=>"success");
        $result->free();
        $mysqli->close();
        echo json_encode($data);    
    }
}




?> 