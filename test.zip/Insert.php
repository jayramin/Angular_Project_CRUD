<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
require 'database.php';
//echo "hi"; exit;
// Get the posted data.
$postdata = file_get_contents("php://input");
// echo json_encode($postdata); 
// exit;
$sql = "INSERT INTO `emp_master`(`empname`,`empmobile`,`empcity`) VALUES ('$request->empname','$request->empmobile','$request->empcity')";
  
  //$ex = mysqli_query($con,$sql);

  if(mysqli_query($conn, $sql))
    {
        http_response_code(204);
    }
    else
    {
        return http_response_code(422);
    }
    
    exit();

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
//print_r($request);
  // Validate.
//   if(trim($request->empname) === '' || $request->empcity == '' || (float)$request->empmobile  < 0)
//   {
//     return http_response_code(400);
//   }
  
  
  // Create.
  
  
}