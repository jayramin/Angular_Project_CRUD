<?php
header("Access-Control-Allow-Origin: *");

require 'database.php';
//echo "hi"; exit;
// Get the posted data.
$postdata = file_get_contents("php://input");
//print_r($postdata); 
if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
//print_r($request);
  // Validate.
  if(trim($request->empname) === '' || $request->empcity == '' || (float)$request->empmobile  < 0)
  {
    return http_response_code(400);
  }
  
  echo $sql = "SELECT empid, empname, empmobile,empcity FROM emp_master  WHERE `empid` = '$request->empid' LIMIT 1";
  exit;
  if (!$result = $mysqli->query($sql))
  {
        echo json_decode($postdata);
  }
  else
  {
      if ($result->num_rows === 0)
      {
        $sql = "INSERT INTO `emp_master`(`empname`,`empmobile`,`empcity`) VALUES ('$request->empname','$request->empmobile','$request->empcity')";
      }
      else
      {
        $sql = "UPDATE `emp_master` SET `empname`='$request->empname',`empmobile`='$request->empmobile',`empcity`='$request->empcity' WHERE `empid` = '$request->empid' LIMIT 1";
      }
  }
  // Create.
 // $sql = "INSERT INTO `emp_master`(`empname`,`empmobile`,`empcity`) VALUES ('$request->empname','$request->empmobile','$request->empcity')";
  
  //$ex = mysqli_query($con,$sql);

  if(mysqli_query($conn, $sql))
    {
        http_response_code(204);
    }
    else
    {
        return http_response_code(422);
    }
  
}