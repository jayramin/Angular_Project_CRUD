 <?php
// header("Access-Control-Allow-Origin: *");

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "employee";

// // Create connection
// $conn = new mysqli($servername, $username, $password, $dbname);

// if(isset($_REQUEST['id']))
// {
//     $id = $_REQUEST['id'];
//     $sql = "DELETE FROM `emp_master` WHERE `empid` = '$id'";
//     $ex = $conn->query($sql);    
// }

// return http_response_code('204');

require 'database.php';
// Extract, validate and sanitize the id.
$id = ($_GET['id']);
//echo $id;
if(!$id)
{
  return http_response_code(400);
}
// Delete.
$sql = "DELETE FROM `emp_master` WHERE `empid`=$id LIMIT 1";
if(mysqli_query($conn, $sql))
{
  http_response_code(204);
}
else
{
  return http_response_code(422);
}


?> 