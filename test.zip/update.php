<?php
header("Access-Control-Allow-Origin: *");
require 'databse.php';
// Get the posted data.
$postdata = file_get_contents("php://input");
if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
  
  echo $sql = "UPDATE `emp_master` SET `empname`='$request->empname',`empmobile`='$request->empmobile',`empcity`='$request->empcity' WHERE `empid` = '$request->empid' LIMIT 1";
  
  if(mysqli_query($con, $sql))
  {
    http_response_code(204);
  }
  else
  {
    return http_response_code(422);
  }  
}
?>