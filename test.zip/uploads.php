<?php
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");
$response = array();
$upload_dir = 'uploads/';

if($_FILES['avatar'])
{
    $avatar_name = $_FILES["avatar"]["name"];
    $avatar_tmp_name = $_FILES["avatar"]["tmp_name"];
    $error = $_FILES["avatar"]["error"];
    
    if(move_uploaded_file($avatar_tmp_name , "uploads/$avatar_name")){
        $response = array(
            "status" => "done",
            "error" => false,
            "message" => "Success!"
        );    
    }else{
        $response = array(
            "status" => "check",
            "error" => true,
            "message" => "not!"
        );
    }
        echo json_encode($response);
        exit();
}

?>